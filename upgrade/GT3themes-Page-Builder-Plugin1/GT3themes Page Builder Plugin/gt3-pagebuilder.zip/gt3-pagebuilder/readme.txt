=== GT3 Pagebuilder ===
Contributors: GT3Themes
Tags: page builder, drag and drop, page
Requires at least: 3.9
Tested up to: 3.9.2
Stable tag: 3.9.2
License: GPLv2 or later

Build your WordPress site in a minute with drag & drop GT3 Page Builder.

== Description ==

[GT3 Page Builder] is a powerful WordPress plugin for building unlimited number of custom pages. It helps to manage the content on the pages through the user-friendly and drag & drop GT3 system. Build your web sites easily.

== Installation ==

Upload plugin to your blog and activate it.

== Changelog ==

= 2.1 =
* More functionality

= 2.0 =
* Release